from topsis_experimental.topsis_experimental import main

if __name__ == "__main__":
    main(sys.argv[1:])